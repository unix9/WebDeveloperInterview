public class Stack implements IQueueable {

    private String[] stack;
    private int top;

    public Stack(int capacity) {
        stack = new String[capacity];
        top = -1;
    }
    @Override
    public String[] enqueue(String value) {
        if (top == stack.length - 1) {
            throw new IllegalStateException("Stack is full");
        }
        stack[++top] = value;
        return getQueue();
    }

    @Override
    public String dequeue() {
        if (top == -1) {
            throw new IllegalStateException("Stack is empty.");
        }
        String item = stack[top--];
        return item;
    }

    @Override
    public String[] getQueue() {
        String[] copy = new String[top+1];
        for(int i = 0; i <= top; i++) {
            copy[i] = stack[i];
        }
        return copy;
    }

    @Override
    public int size() {
        return top + 1;
    }
}
