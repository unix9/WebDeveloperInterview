public class Queue implements IQueueable {

    private String[] queue;
    private int head;
    private int tail;
    private int size;

    public Queue(int capacity) {
        queue = new String[capacity];
        head = 0;
        tail = 0;
        size = 0;
    }

    @Override
    public String[] enqueue(String value) {
        if(size == queue.length)
        {
            throw new IllegalStateException("Queue is full.");
        }
        queue[tail] = value;
        tail = (tail + 1) % queue.length;
        size++;
        return getQueue();
    }

    @Override
    public String dequeue() {
        if (size == 0) {
            throw new IllegalStateException("Queue is empty.");

        }
        String item = queue[head];
        head = (head + 1) % queue.length;
        size--;
        return item;
    }

    @Override
    public String[] getQueue() {
        String[] copy = new String [size];
        int j = 0;
        for (int i = head; i < head + size; i++) {
            copy[j++] = queue[i % queue.length];
        }
        return copy;
    }

    @Override
    public int size() {
        return size;
    }
}
